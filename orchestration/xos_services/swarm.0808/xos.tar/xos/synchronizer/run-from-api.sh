mkdir -p /root/.ssh/;  cp -f /opt/cord_profile/node_key  /root/.ssh/id_rsa ; python swarm-synchronizer.py
